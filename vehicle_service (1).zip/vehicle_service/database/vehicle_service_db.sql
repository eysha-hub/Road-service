-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 07, 2022 at 10:54 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vehicle_service_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(30) NOT NULL,
  `category` varchar(250) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category`, `status`, `date_created`) VALUES
(1, '2 Wheeler Vehicle', 1, '2022-03-11 09:43:00'),
(2, '3 Wheeler Vehicle', 1, '2022-03-11 09:43:00'),
(3, '4 Wheeler Vehicle', 1, '2022-03-11 09:43:00'),
(4, '6 Wheeler Vehicle', 1, '2022-03-11 09:43:00');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `create_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `username`, `email`, `password`, `create_datetime`) VALUES
(1, 'Aurelia', 'a@gmaill.com', '827ccb0eea8a706c4c34a16891f84e7b', '2022-03-25 11:08:44'),
(2, 'aisha', 'aisha@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2022-02-08 17:18:34'),
(3, 'fardosa', 'fardosa@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '2022-02-08 17:39:16'),
(4, 'james', 'jm@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '2022-04-07 10:12:02');

-- --------------------------------------------------------

--
-- Table structure for table `mechanics_list`
--

CREATE TABLE `mechanics_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `contact` varchar(50) NOT NULL,
  `email` varchar(150) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mechanics_list`
--

INSERT INTO `mechanics_list` (`id`, `name`, `contact`, `email`, `status`, `date_created`) VALUES
(1, 'John Smith', '07123456789', 'jsmith@gmail.com', 1, '2022-03-24 10:26:11'),
(2, 'George Wilson', '07112355799', 'gwilson@gmail.com', 1, '2022-03-25 10:30:58');

-- --------------------------------------------------------
--
-- Table structure for table `request_meta`
--

CREATE TABLE `request_meta` (
  `request_id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `request_meta`
--

INSERT INTO `request_meta` (`request_id`, `meta_field`, `meta_value`) VALUES
(3, 'contact', 'none'),
(3, 'email', 'wnulkabaraerxfdxtp@mrvpm.net'),
(3, 'address', 'nairobi'),
(3, 'vehicle_name', 'madza 4'),
(3, 'vehicle_registration_number', 'kbc 009k'),
(3, 'vehicle_model', 'mazda'),
(3, 'service_id', '4'),
(3, 'pickup_address', 'ngara'),
(1, 'contact', '09112355799'),
(1, 'email', 'collins@gmail.com'),
(1, 'address', 'Roysambu'),
(1, 'vehicle_name', 'Mitsubishi Montero Sport'),
(1, 'vehicle_registration_number', 'GBN 0623'),
(1, 'vehicle_model', 'CDM-10140715'),
(1, 'service_id', '1,3,4'),
(1, 'pickup_address', 'Trm drive'),
(4, 'contact', '0766990887'),
(4, 'email', 'a@gmaill.com'),
(4, 'address', 'Ngara'),
(4, 'vehicle_name', 'madza 4'),
(4, 'vehicle_registration_number', 'kbc 009y'),
(4, 'vehicle_model', 'mazda'),
(4, 'service_id', '1,3,2,4'),
(4, 'pickup_address', 'Ngara, foot bridge.'),
(5, 'contact', 'kjggfffddd'),
(5, 'email', 'salaxudin@gmail.com'),
(5, 'address', 'nairobi kenya'),
(5, 'vehicle_name', 'jjkkk'),
(5, 'vehicle_registration_number', 'kkjhggf'),
(5, 'vehicle_model', 'hggjjj'),
(5, 'service_id', '3'),
(5, 'pickup_address', 'hkhgggg');

-- --------------------------------------------------------

--
-- Table structure for table `service_list`
--

CREATE TABLE `service_list` (
  `id` int(30) NOT NULL,
  `service` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_list`
--

INSERT INTO `service_list` (`id`, `service`, `description`, `status`, `date_created`) VALUES
(2, 'Overall Checkup', '&lt;p&gt;&lt;span style=&quot;color: rgb(189, 193, 198); font-family: arial, sans-serif; background-color: rgb(32, 33, 36);&quot;&gt;car health check-up along with submission of an inspection report outlining the&amp;nbsp;&lt;/span&gt;&lt;b style=&quot;color: rgb(189, 193, 198); font-family: arial, sans-serif; background-color: rgb(32, 33, 36);&quot;&gt;health of your car&#039;s internals&lt;/b&gt;&lt;span style=&quot;color: rgb(189, 193, 198); font-family: arial, sans-serif; background-color: rgb(32, 33, 36);&quot;&gt;, 100ml of engine oil top-up, 50ml of coolant fluid top-up, complete exterior foam wash and interior vacuuming. Our service partners will submit an inspection report of your car.&lt;/span&gt;&lt;/p&gt;&lt;ol&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Amount Kshs 5,000&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Paypal Account: 0700000001&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;The confirmation message will be sent to you.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;You can use Mpesa paybill number: 2222209&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Enter account Number as your email or phone number&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;We are here to serve you at your comfort.&amp;nbsp;&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 1, '2021-09-30 14:11:38'),
(3, 'Engine Tune up', '&lt;p&gt;&lt;span style=&quot;color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; background-color: rgb(255, 255, 255);&quot;&gt;As our engines have changed over time, so have our engine tune-ups. In the past, it was necessary to check and change many more parts. Today, engine tune-ups include checking, diagnosing, and replacing bad spark plugs, spark plug wires, distributor caps, fuel filters, air filters, and oil filters. Tune-ups can also include checking emission levels, fuel lines, wiring, coolant hoses, and serpentine belts. Checking items such as ignition contact points, ignition timing, carburetors, and condensers aren&rsquo;t included anymore because today&rsquo;s vehicles include electronic ignitions as well as computers that automatically adjust engine timing when necessary.&lt;/span&gt;&lt;/p&gt;&lt;ol&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Amount Kshs 2,500&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Paypal Account: 0700000001&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;The confirmation message will be sent to you.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;You can use Mpesa paybill number: 2222209&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Enter account Number as your email or phone number&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;We are here to serve you at your comfort.&amp;nbsp;&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;&lt;br&gt;&lt;/p&gt;', 1, '2021-09-30 14:12:03'),
(4, 'Tire Replacement', '&lt;p&gt;&lt;b class=&quot;whb&quot; style=&quot;-webkit-tap-highlight-color: transparent; margin: 0px; padding: 0px; border: 0px; font-variant-numeric: inherit; font-variant-east-asian: inherit; font-weight: bold; font-stretch: inherit; line-height: inherit; font-family: Helvetica, &quot; nimbus=&quot;&quot; sans=&quot;&quot; l&quot;,=&quot;&quot; arial,=&quot;&quot; &quot;liberation=&quot;&quot; sans&quot;,=&quot;&quot; sans-serif;=&quot;&quot; vertical-align:=&quot;&quot; baseline;=&quot;&quot; background:=&quot;&quot; none=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(84,=&quot;&quot; 84,=&quot;&quot; 84);&quot;=&quot;&quot;&gt;Find a flat, stable and safe place to change your tire.&lt;/b&gt;&lt;span style=&quot;color: rgb(84, 84, 84); font-family: Helvetica, &quot; nimbus=&quot;&quot; sans=&quot;&quot; l&quot;,=&quot;&quot; arial,=&quot;&quot; &quot;liberation=&quot;&quot; sans&quot;,=&quot;&quot; sans-serif;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot;&gt;&amp;nbsp;You should have a solid, level surface that will restrict the car from rolling. If you are near a road, park as far from traffic as possible and turn on your emergency flashers (hazard lights). Avoid soft ground and hills.&lt;/span&gt;&lt;/p&gt;&lt;ol&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Amount Kshs 2,800&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Paypal Account: 0700000001&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;The confirmation message will be sent to you.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;You can use Mpesa paybill number: 2222209&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Enter account Number as your email or phone number&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;We are here to serve you at your comfort.&amp;nbsp;&lt;/li&gt;&lt;/ol&gt;&lt;p&gt;&lt;span style=&quot;color: rgb(84, 84, 84); font-family: Helvetica, &quot; nimbus=&quot;&quot; sans=&quot;&quot; l&quot;,=&quot;&quot; arial,=&quot;&quot; &quot;liberation=&quot;&quot; sans&quot;,=&quot;&quot; sans-serif;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot;&gt;&lt;/span&gt;&lt;br&gt;&lt;/p&gt;', 1, '2021-09-30 14:12:24'),
(5, 'Change Oil', '&lt;p style=&quot;text-align: justify; &quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; margin-top:=&quot;&quot; 2px;=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;To ensure that your vehicle and its mechanical parts work properly, it is essential to check and change your engine oil regularly. We will provide you with&amp;nbsp;the steps to follow when&amp;nbsp;&lt;/span&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;checking your oil level and changing your oil.&amp;nbsp;&lt;/span&gt;&lt;/p&gt;&lt;ol&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Amount Kshs 2,000&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Paypal Account: 0700000001&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;The confirmation message will be sent to you.&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;You can use Mpesa paybill number: 2222209&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;&lt;span noto=&quot;&quot; sans&quot;;=&quot;&quot; letter-spacing:=&quot;&quot; 0.1px;=&quot;&quot; background-color:=&quot;&quot; rgb(255,=&quot;&quot; 255,=&quot;&quot; 255);&quot;=&quot;&quot; style=&quot;font-family: &quot; apple=&quot;&quot; chancery&quot;,=&quot;&quot; cursive;=&quot;&quot; 255);=&quot;&quot; color:=&quot;&quot; rgb(55,=&quot;&quot; 70,=&quot;&quot; 73);&quot;=&quot;&quot;&gt;Enter account Number as your email or phone number&lt;/span&gt;&lt;/li&gt;&lt;li style=&quot;text-align: justify;&quot;&gt;We are here to serve you at your comfort.&amp;nbsp;&lt;/li&gt;&lt;/ol&gt;', 1, '2022-04-07 10:55:57');

-- --------------------------------------------------------

--
-- Table structure for table `service_requests`
--

CREATE TABLE `service_requests` (
  `id` int(30) NOT NULL,
  `owner_name` text NOT NULL,
  `category_id` int(30) NOT NULL,
  `service_type` text NOT NULL,
  `mechanic_id` int(30) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `service_requests`
--

INSERT INTO `service_requests` (`id`, `owner_name`, `category_id`, `service_type`, `mechanic_id`, `status`, `date_created`) VALUES
(1, 'Collins Oduor', 3, 'Pick Up', 1, 3, '2021-09-30 14:48:57'),
(3, 'fardosa', 2, 'Pick Up', 1, 1, '2022-02-14 06:49:09'),
(4, 'Aurelia Jerop', 2, 'Pick Up', NULL, 0, '2022-03-25 13:33:36'),
(5, 'james', 2, 'Pick Up', 1, 1, '2022-04-06 08:07:51');

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Road Breakdown Finder System'),
(6, 'short_name', 'Road Finder'),
(11, 'logo', 'uploads/1632965940_vrs-logo.jpg'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/1644823320_home3.jpg');

-- --------------------------------------------------------
--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Adminstrator', 'Admin', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/1624240500_avatar.png', NULL, 1, '2021-01-20 14:02:37', '2021-06-21 09:55:07'),
(6, 'Claire', 'Blake', 'cblake', 'cd74fae0a3adf459f73bbf187607ccea', 'uploads/1632990840_ava.jpg', NULL, 2, '2021-09-30 16:34:02', '2021-09-30 16:35:26');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `mechanics_list`
--
ALTER TABLE `mechanics_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payment_transaction`
--

--
-- Indexes for table `request_meta`
--
ALTER TABLE `request_meta`
  ADD KEY `request_id` (`request_id`);

--
-- Indexes for table `service_list`
--
ALTER TABLE `service_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `service_requests`
--
ALTER TABLE `service_requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);



--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `mechanics_list`
--
ALTER TABLE `mechanics_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;


-- AUTO_INCREMENT for table `service_list`
--
ALTER TABLE `service_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `service_requests`
--
ALTER TABLE `service_requests`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `request_meta`
--
ALTER TABLE `request_meta`
  ADD CONSTRAINT `request_meta_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `service_requests` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
